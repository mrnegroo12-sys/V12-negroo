package com.sketchbot.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** ألوان وأدوات التصميم الزجاجي (Glassmorphism) */
object Ui {
    val BG = Color.parseColor("#050A12")
    val C1 = Color.parseColor("#4F5BFF") // أزرق نيلي
    val C2 = Color.parseColor("#22D3EE") // سماوي
    val C3 = Color.parseColor("#7C5CFF") // بنفسجي هادئ
    val TEXT = Color.parseColor("#F2F6FC")
    val SUB = Color.parseColor("#9FB0C8")

    /** ألوان بلاطة الأيقونة (على طريقة أيقونات iOS): [أعلى, أسفل] */
    fun tile(type: Int): IntArray = when (type) {
        Ic.PLAY, Ic.POWER -> intArrayOf(Color.parseColor("#4ADE80"), Color.parseColor("#0FB5A6"))
        Ic.STOP -> intArrayOf(Color.parseColor("#FF7A7A"), Color.parseColor("#E8325C"))
        Ic.LAYERS -> intArrayOf(Color.parseColor("#9A8CFF"), Color.parseColor("#5B3DF5"))
        Ic.PALETTE -> intArrayOf(Color.parseColor("#FFC15E"), Color.parseColor("#FF5E8A"))
        Ic.BUCKET -> intArrayOf(Color.parseColor("#2DE2C6"), Color.parseColor("#0A8FB5"))
        Ic.BRUSH -> intArrayOf(Color.parseColor("#FF7EB6"), Color.parseColor("#8E5CFF"))
        Ic.TEST -> intArrayOf(Color.parseColor("#FFE066"), Color.parseColor("#FF9A1F"))
        Ic.RULER -> intArrayOf(Color.parseColor("#A7B4CC"), Color.parseColor("#5E6E8E"))
        Ic.PIZZA -> intArrayOf(Color.parseColor("#FFC15E"), Color.parseColor("#FF7A45"))
        else -> intArrayOf(Color.parseColor("#35D6FF"), Color.parseColor("#2F6BFF"))
    }

    fun alpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density).toInt()
    fun medium(): Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    fun black(): Typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
}

/** خلفية زجاجية: تدرّج شفاف أبيض مع حدّ لامع */
class GlassDrawable(
    private val radiusDp: Float,
    private val density: Float,
    private val strength: Float = 1f,
    private val tint: Int = Color.WHITE,
    private val dark: Boolean = false
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = max(1f, density)
    }
    private val rect = RectF()

    override fun onBoundsChange(b: Rect) {
        rect.set(b.left + 0.5f * density, b.top + 0.5f * density, b.right - 0.5f * density, b.bottom - 0.5f * density)
        val r = Color.red(tint)
        val g = Color.green(tint)
        val bl = Color.blue(tint)
        fill.shader = if (dark) LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            Color.argb(0xE8, 22, 30, 48), Color.argb(0xDC, 9, 13, 24),
            Shader.TileMode.CLAMP
        ) else LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            Color.argb((0x3C * strength).toInt().coerceIn(0, 255), r, g, bl),
            Color.argb((0x10 * strength).toInt().coerceIn(0, 255), r, g, bl),
            Shader.TileMode.CLAMP
        )
        stroke.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            Color.argb(0xB0, 255, 255, 255), Color.argb(0x20, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
    }

    override fun draw(c: Canvas) {
        val r = radiusDp * density
        c.drawRoundRect(rect, r, r, fill)
        c.drawRoundRect(rect, r, r, stroke)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** خلفية الشفق المتحركة (كتل لونية ضبابية تعطي عمقاً للزجاج) */
class AuroraView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 20000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(Ui.BG)
        blob(c, w * (0.2f + 0.15f * sin(t)), h * (0.14f + 0.07f * cos(t)), w * 0.95f, Ui.C2)
        blob(c, w * (0.88f + 0.08f * cos(t)), h * (0.5f + 0.08f * sin(t)), w * 0.85f, Ui.C1)
        blob(c, w * (0.28f + 0.12f * cos(t + 1f)), h * (0.9f + 0.05f * sin(t)), w * 0.9f, Ui.C3)
    }

    private fun blob(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        p.shader = RadialGradient(x, y, r, intArrayOf(Ui.alpha(col, 0x55), Ui.alpha(col, 0)), null, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
    }
}

object Ic {
    const val IMAGE = 0
    const val PLAY = 1
    const val STOP = 2
    const val AREA = 3
    const val LAYERS = 4
    const val PALETTE = 5
    const val BUCKET = 6
    const val BRUSH = 7
    const val TEST = 8
    const val RULER = 9
    const val MENU = 10
    const val POWER = 11
    const val SLIDERS = 12
    const val PIZZA = 13
    const val GEAR = 14
    const val BACK = 15
    const val UNDO = 16
    const val PENCIL = 17
    const val CHECKER = 18
    const val SHARE = 19
    const val MOON = 20
    const val SUN = 21
}

/** أيقونة مرسومة بالكود (خطوط ناعمة بتدرّج سماوي ← بنفسجي) */
class IconView(ctx: Context, private val type: Int, private val c1: Int = 0, private val c2: Int = 0, ink: Int = 0, private val water: Boolean = false) : View(ctx) {
    private val tile = c1 != 0
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = if (c1 != 0) 2.2f else 1.9f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()

    init {
        if (tile) {
            val gc = if (ink != 0) ink else Color.WHITE
            stroke.color = gc
            fill.color = gc
        } else if (ink != 0) {
            stroke.color = ink
            fill.color = ink
        } else {
            val sh = LinearGradient(2f, 2f, 22f, 22f, Ui.C2, Ui.C1, Shader.TileMode.CLAMP)
            stroke.shader = sh
            fill.shader = sh
        }
    }

    fun setInk(col: Int) {
        stroke.shader = null
        fill.shader = null
        stroke.color = col
        fill.color = col
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val sz = min(width, height).toFloat()
        if (tile) {
            val r = sz * 0.27f
            rr.set(0f, 0f, sz, sz)
            tp.style = Paint.Style.FILL
            tp.color = Color.BLACK
            tp.shader = LinearGradient(0f, 0f, 0f, sz, c1, c2, Shader.TileMode.CLAMP)
            c.drawRoundRect(rr, r, r, tp)
            tp.shader = LinearGradient(0f, 0f, 0f, sz * 0.55f, Color.argb(0x55, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
            c.drawRoundRect(rr, r, r, tp)
            if (water) {
                // لمعة داخلية سفلية + قطرات ماء
                tp.style = Paint.Style.FILL
                tp.shader = RadialGradient(sz * 0.75f, sz * 0.95f, sz * 0.8f, Color.argb(0x50, 255, 240, 220), Color.argb(0, 255, 240, 220), Shader.TileMode.CLAMP)
                c.drawRoundRect(rr, r, r, tp)
                tp.shader = null
                val dx = floatArrayOf(0.80f, 0.17f, 0.85f, 0.30f, 0.62f, 0.10f)
                val dy = floatArrayOf(0.20f, 0.74f, 0.62f, 0.14f, 0.88f, 0.40f)
                val dr = floatArrayOf(0.07f, 0.06f, 0.05f, 0.04f, 0.045f, 0.03f)
                for (i in dx.indices) {
                    val cx = sz * dx[i]
                    val cy = sz * dy[i]
                    val rd = sz * dr[i]
                    tp.style = Paint.Style.FILL
                    tp.color = Color.argb(0x38, 255, 255, 255)
                    c.drawCircle(cx, cy, rd, tp)
                    tp.style = Paint.Style.STROKE
                    tp.strokeWidth = max(1f, sz * 0.012f)
                    tp.color = Color.argb(0x70, 255, 255, 255)
                    c.drawCircle(cx, cy, rd, tp)
                    tp.style = Paint.Style.FILL
                    tp.color = Color.argb(0xD0, 255, 255, 255)
                    c.drawCircle(cx - rd * 0.3f, cy - rd * 0.3f, rd * 0.3f, tp)
                }
            }
            tp.shader = null
            tp.style = Paint.Style.STROKE
            tp.strokeWidth = max(1f, sz * 0.03f)
            tp.color = Color.argb(0x45, 255, 255, 255)
            c.drawRoundRect(rr, r, r, tp)
            val s = sz * 0.56f / 24f
            c.save()
            c.translate(sz * 0.22f, sz * 0.22f)
            c.scale(s, s)
            draw24(c)
            c.restore()
        } else {
            val s = sz / 24f
            c.save()
            c.scale(s, s)
            draw24(c)
            c.restore()
        }
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(x1, y1, x2, y2, stroke)

    private fun draw24(c: Canvas) {
        when (type) {
            Ic.IMAGE -> {
                c.drawRoundRect(RectF(3f, 4f, 21f, 20f), 3f, 3f, stroke)
                c.drawCircle(9f, 10f, 1.6f, fill)
                val p = Path().apply { moveTo(3f, 17f); lineTo(9f, 12.5f); lineTo(14f, 17f); lineTo(17f, 14.5f); lineTo(21f, 18f) }
                c.drawPath(p, stroke)
            }
            Ic.PLAY -> {
                val p = Path().apply { moveTo(8f, 5f); lineTo(19f, 12f); lineTo(8f, 19f); close() }
                c.drawPath(p, fill)
                c.drawPath(p, stroke)
            }
            Ic.STOP -> {
                c.drawRoundRect(RectF(6f, 6f, 18f, 18f), 2.5f, 2.5f, fill)
                c.drawRoundRect(RectF(6f, 6f, 18f, 18f), 2.5f, 2.5f, stroke)
            }
            Ic.AREA -> {
                val p = Path().apply {
                    moveTo(4f, 9f); lineTo(4f, 4f); lineTo(9f, 4f)
                    moveTo(15f, 4f); lineTo(20f, 4f); lineTo(20f, 9f)
                    moveTo(20f, 15f); lineTo(20f, 20f); lineTo(15f, 20f)
                    moveTo(9f, 20f); lineTo(4f, 20f); lineTo(4f, 15f)
                }
                c.drawPath(p, stroke)
            }
            Ic.LAYERS -> {
                val p = Path().apply {
                    moveTo(12f, 3f); lineTo(21f, 8f); lineTo(12f, 13f); lineTo(3f, 8f); close()
                    moveTo(3f, 12f); lineTo(12f, 17f); lineTo(21f, 12f)
                    moveTo(3f, 16f); lineTo(12f, 21f); lineTo(21f, 16f)
                }
                c.drawPath(p, stroke)
            }
            Ic.PALETTE -> {
                c.drawCircle(12f, 12f, 9f, stroke)
                c.drawCircle(8f, 10.5f, 1.3f, fill)
                c.drawCircle(12f, 7.5f, 1.3f, fill)
                c.drawCircle(16f, 10.5f, 1.3f, fill)
                c.drawCircle(9f, 15.5f, 1.3f, fill)
            }
            Ic.BUCKET -> {
                val p = Path().apply { moveTo(5f, 12f); lineTo(11f, 5f); lineTo(18f, 12f); lineTo(11f, 19f); close() }
                c.drawPath(p, stroke)
                line(c, 8f, 8.5f, 14.5f, 15f)
                val drop = Path().apply { moveTo(20.5f, 14f); quadTo(23.5f, 18f, 20.5f, 20.5f); quadTo(17.5f, 18f, 20.5f, 14f); close() }
                c.drawPath(drop, fill)
            }
            Ic.BRUSH -> {
                val p = Path().apply {
                    moveTo(14f, 5f); lineTo(19f, 10f); lineTo(10f, 19f)
                    quadTo(7f, 21f, 5f, 19f); quadTo(4f, 17f, 6f, 14f); close()
                }
                c.drawPath(p, stroke)
                line(c, 9f, 15f, 12f, 12f)
            }
            Ic.TEST -> {
                val p = Path().apply {
                    moveTo(9f, 3f); lineTo(15f, 3f)
                    moveTo(10f, 3f); lineTo(10f, 9f); lineTo(5f, 19f); quadTo(4f, 21f, 6.5f, 21f)
                    lineTo(17.5f, 21f); quadTo(20f, 21f, 19f, 19f); lineTo(14f, 9f); lineTo(14f, 3f)
                    moveTo(7.5f, 15f); lineTo(16.5f, 15f)
                }
                c.drawPath(p, stroke)
            }
            Ic.RULER -> {
                c.save()
                c.rotate(-45f, 12f, 12f)
                c.drawRoundRect(RectF(1.5f, 8f, 22.5f, 16f), 2f, 2f, stroke)
                for (x in floatArrayOf(6f, 10f, 14f, 18f)) line(c, x, 8f, x, 11.5f)
                c.restore()
            }
            Ic.MENU -> {
                line(c, 4f, 7f, 20f, 7f); line(c, 4f, 12f, 20f, 12f); line(c, 4f, 17f, 20f, 17f)
            }
            Ic.POWER -> {
                c.drawArc(RectF(5f, 5f, 19f, 19f), -60f, 300f, false, stroke)
                line(c, 12f, 3f, 12f, 12f)
            }
            Ic.SLIDERS -> {
                line(c, 4f, 7f, 20f, 7f); line(c, 4f, 12f, 20f, 12f); line(c, 4f, 17f, 20f, 17f)
                c.drawCircle(8f, 7f, 2f, fill); c.drawCircle(16f, 12f, 2f, fill); c.drawCircle(10f, 17f, 2f, fill)
            }
            Ic.GEAR -> {
                val p = Path()
                for (i in 0 until 16) {
                    val rad = if (i % 2 == 0) 10f else 7.8f
                    val ang = i * PI.toFloat() / 8f
                    val x = 12f + rad * cos(ang)
                    val y = 12f + rad * sin(ang)
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                c.drawPath(p, stroke)
                c.drawCircle(12f, 12f, 3.2f, stroke)
            }
            Ic.BACK -> {
                val p = Path().apply { moveTo(15f, 5f); lineTo(8f, 12f); lineTo(15f, 19f) }
                c.drawPath(p, stroke)
            }
            Ic.UNDO -> {
                val p = Path().apply {
                    moveTo(4f, 11f); lineTo(14f, 11f)
                    cubicTo(18f, 11f, 20f, 13f, 20f, 16f)
                    cubicTo(20f, 19f, 18f, 21f, 14f, 21f); lineTo(9f, 21f)
                    moveTo(9f, 6f); lineTo(4f, 11f); lineTo(9f, 16f)
                }
                c.drawPath(p, stroke)
            }
            Ic.PENCIL -> {
                val p = Path().apply { moveTo(4f, 20f); lineTo(5f, 15f); lineTo(16f, 4f); lineTo(20f, 8f); lineTo(9f, 19f); close() }
                c.drawPath(p, stroke)
                line(c, 13.5f, 6.5f, 17.5f, 10.5f)
            }
            Ic.CHECKER -> {
                c.drawRoundRect(RectF(3f, 3f, 21f, 21f), 2f, 2f, stroke)
                for (r in 0 until 3) for (cc in 0 until 3) if ((r + cc) % 2 == 0) c.drawRect(3f + cc * 6f, 3f + r * 6f, 9f + cc * 6f, 9f + r * 6f, fill)
            }
            Ic.SHARE -> {
                val p = Path().apply {
                    moveTo(12f, 15f); lineTo(12f, 3f)
                    moveTo(8f, 7f); lineTo(12f, 3f); lineTo(16f, 7f)
                    moveTo(6f, 11f); lineTo(6f, 20f); lineTo(18f, 20f); lineTo(18f, 11f)
                }
                c.drawPath(p, stroke)
            }
            Ic.MOON -> {
                val a = Path().apply { addCircle(11.5f, 12.5f, 8f, Path.Direction.CW) }
                val b = Path().apply { addCircle(16f, 9f, 6.6f, Path.Direction.CW) }
                a.op(b, Path.Op.DIFFERENCE)
                c.drawPath(a, fill)
                c.drawPath(a, stroke)
                c.drawCircle(19f, 17f, 0.9f, fill)
            }
            Ic.SUN -> {
                c.drawCircle(12f, 12f, 4.2f, fill)
                for (i in 0 until 8) {
                    val ang = Math.toRadians(i * 45.0)
                    val cs = Math.cos(ang).toFloat()
                    val sn = Math.sin(ang).toFloat()
                    line(c, 12f + cs * 7.6f, 12f + sn * 7.6f, 12f + cs * 10f, 12f + sn * 10f)
                }
            }
            Ic.PIZZA -> {
                val p = Path().apply { moveTo(3f, 6f); quadTo(12f, 2f, 21f, 6f); lineTo(12f, 21f); close() }
                c.drawPath(p, stroke)
                c.drawCircle(10f, 9f, 1.3f, fill)
                c.drawCircle(14f, 10f, 1.3f, fill)
                c.drawCircle(12f, 14f, 1.3f, fill)
            }
        }
    }
}

/** نص بتدرّج لوني (للعناوين) */
class GradientText(ctx: Context) : TextView(ctx) {
    override fun onDraw(c: Canvas) {
        val w = max(1f, width.toFloat())
        paint.shader = LinearGradient(0f, 0f, w, 0f, intArrayOf(Ui.C2, Color.WHITE, Ui.C3), null, Shader.TileMode.CLAMP)
        super.onDraw(c)
    }
}

/** زر زجاجي بأيقونة ونص مع حركة ضغط */
class GlassButton(
    ctx: Context,
    icon: Int,
    caption: String,
    accent: Boolean = false,
    compact: Boolean = false
) : LinearLayout(ctx) {
    private val label = TextView(ctx)
    var text: CharSequence
        get() = label.text
        set(v) { label.text = v }

    init {
        val d = ctx.resources.displayMetrics.density
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val hp = if (compact) 7 else 16
        val vp = if (compact) 6 else 11
        setPadding((hp * d).toInt(), (vp * d).toInt(), (hp * d).toInt(), (vp * d).toInt())
        background = GlassDrawable(if (compact) 16f else 20f, d, if (accent) 2.2f else 1f, if (accent) Ui.C2 else Color.WHITE)
        val isz = ((if (compact) 26 else 32) * d).toInt()
        val tl = Ui.tile(icon)
        addView(IconView(ctx, icon, tl[0], tl[1]), LayoutParams(isz, isz))
        label.apply {
            setTextColor(Ui.TEXT)
            textSize = if (compact) 11.5f else 14.5f
            typeface = Ui.medium()
            letterSpacing = 0.02f
            setPadding((8 * d).toInt(), 0, 0, 0)
            this.text = caption
            maxLines = 1
        }
        addView(label, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        isClickable = true
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).alpha(0.85f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(140).start()
            }
            false
        }
    }
}

/** مقدمة سينمائية: خط ضوء يمسح فيكشف الاسم الزجاجي المعدني، ثم يتشقق الزجاج ويتحطم ويكشف الواجهة */
class SplashView(ctx: Context, private val onDone: () -> Unit) : View(ctx) {
    private class Shard(
        val path: Path, val cx: Float, val cy: Float,
        val vx: Float, val vy: Float, val rot: Float, val depth: Float
    )

    private var tb: Bitmap? = null
    private val shards = ArrayList<Shard>()
    private var ox = 0f
    private var oy = 0f
    private var tagY = 0f
    private var t = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haze = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val barP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE }
    private val crackP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
    }
    private val tagP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.SUB
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.5f
        typeface = Ui.medium()
    }
    private val sweep = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP) }
    private var cracks: List<FloatArray> = emptyList()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4200
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
        addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(a: android.animation.Animator) { onDone() }
        })
    }

    init { isClickable = true }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        val txt = "MR NEGROO"
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Ui.black()
            letterSpacing = 0.2f
            textSize = 100f
        }
        tp.textSize = 100f * (w * 0.8f / tp.measureText(txt))
        val fm = tp.fontMetrics
        val pad = (tp.textSize * 0.3f).toInt()
        val tw = tp.measureText(txt).toInt() + pad * 2
        val th = (fm.descent - fm.ascent).toInt() + pad * 2
        val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val bc = Canvas(bmp)
        val by = pad - fm.ascent
        val px = pad.toFloat()
        // ظل خفيف يعطي عمقاً
        val sh = Paint(tp).apply {
            style = Paint.Style.FILL
            color = Color.argb(0x50, 0, 0, 0)
            setShadowLayer(tp.textSize * 0.12f, 0f, tp.textSize * 0.05f, Color.argb(0x90, 0, 0, 0))
        }
        bc.drawText(txt, px, by, sh)
        // جسم معدني: تدرّج بأفق انعكاس (كروم)
        val body = Paint(tp).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                0f, pad.toFloat(), 0f, (th - pad).toFloat(),
                intArrayOf(
                    Color.parseColor("#FFFFFF"), Color.parseColor("#C9D6EA"),
                    Color.parseColor("#6F86A8"), Color.parseColor("#B4F1FF"), Color.parseColor("#FFFFFF")
                ),
                floatArrayOf(0f, 0.42f, 0.5f, 0.78f, 1f), Shader.TileMode.CLAMP
            )
        }
        bc.drawText(txt, px, by, body)
        // حد سماوي رفيع
        val edge = Paint(tp).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(1.5f, tp.textSize * 0.014f)
            color = Color.argb(0xC0, 34, 211, 238)
        }
        bc.drawText(txt, px, by, edge)
        tb = bmp
        ox = (w - tw) / 2f
        oy = (h - th) / 2f
        tagY = oy + th + tp.textSize * 0.1f
        tagP.textSize = max(24f, w * 0.03f)

        shards.clear()
        val cols = 16
        val rows = 4
        val rnd = java.util.Random(11)
        val cw = tw / cols.toFloat()
        val ch = th / rows.toFloat()
        for (r in 0 until rows) for (ci in 0 until cols) {
            val x0 = ci * cw
            val y0 = r * ch
            val x1 = x0 + cw
            val y1 = y0 + ch
            for (k in 0..1) {
                val p = Path()
                if (k == 0) { p.moveTo(x0, y0); p.lineTo(x1, y0); p.lineTo(x0, y1) } else { p.moveTo(x1, y0); p.lineTo(x1, y1); p.lineTo(x0, y1) }
                p.close()
                val cx = if (k == 0) (x0 + x1 + x0) / 3f else (x1 + x1 + x0) / 3f
                val cy = if (k == 0) (y0 + y0 + y1) / 3f else (y0 + y1 + y1) / 3f
                val dx = cx - tw / 2f
                val dy = cy - th / 2f
                val vx = dx * 1.2f + (rnd.nextFloat() - 0.5f) * tw * 0.35f
                val vy = dy * 1.0f + (rnd.nextFloat() - 0.6f) * th * 1.2f
                shards.add(Shard(p, cx, cy, vx, vy, (rnd.nextFloat() - 0.5f) * 420f, rnd.nextFloat()))
            }
        }
        val cl = ArrayList<FloatArray>()
        for (i in 0 until 10) {
            val ang = (i * 36f + rnd.nextFloat() * 20f) * (PI.toFloat() / 180f)
            val len = tw * (0.2f + rnd.nextFloat() * 0.32f)
            cl.add(floatArrayOf(ang, len, (rnd.nextFloat() - 0.5f) * 0.7f))
        }
        cracks = cl
    }

    private fun ease(x: Float): Float { val v = x.coerceIn(0f, 1f); return v * v * (3f - 2f * v) }

    override fun onTouchEvent(e: MotionEvent): Boolean = true

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bmp = tb ?: return
        val bgA = (255 * (1f - ease((t - 0.76f) / 0.22f))).toInt().coerceIn(0, 255)
        c.drawColor(Color.argb(bgA, Color.red(Ui.BG), Color.green(Ui.BG), Color.blue(Ui.BG)))
        val cx0 = ox + bmp.width / 2f
        val cy0 = oy + bmp.height / 2f
        // هالة سماوية خافتة خلف الاسم
        haze.shader = RadialGradient(
            cx0, cy0, w * 0.75f,
            intArrayOf(Color.argb(0x30 * bgA / 255, 34, 211, 238), Color.argb(0, 34, 211, 238)),
            null, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx0, cy0, w * 0.75f, haze)

        val d = resources.displayMetrics.density
        // خط الضوء: يتمدد من المنتصف ثم يخفت
        val lineA = ((1f - ease((t - 0.3f) / 0.1f)) * 255).toInt().coerceIn(0, 255)
        if (lineA > 0) {
            val half = w * 0.5f * ease(t / 0.14f)
            lineP.shader = LinearGradient(
                cx0 - half, 0f, cx0 + half, 0f,
                intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(lineA, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                null, Shader.TileMode.CLAMP
            )
            lineP.strokeWidth = 2f * d
            c.drawLine(cx0 - half, cy0, cx0 + half, cy0, lineP)
        }

        if (t < 0.64f) {
            // كشف الاسم بمسحة ضوء من اليسار إلى اليمين
            val rv = ease((t - 0.12f) / 0.28f)
            if (rv > 0f) {
                val rx = ox + bmp.width * rv
                val layer = c.saveLayer(ox, oy, ox + bmp.width, oy + bmp.height, null)
                c.save()
                c.clipRect(ox, oy, rx, oy + bmp.height)
                paint.alpha = 255
                c.drawBitmap(bmp, ox, oy, paint)
                c.restore()
                // لمعان مائل يعبر الحروف بعد اكتمال الكشف
                val sx = ox - 120f + (bmp.width + 240f) * ease((t - 0.42f) / 0.2f)
                sweep.shader = LinearGradient(
                    sx - 70f, 0f, sx + 70f, 0f,
                    intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(0xC8, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                    null, Shader.TileMode.CLAMP
                )
                c.drawRect(ox, oy, ox + bmp.width, oy + bmp.height, sweep)
                c.restoreToCount(layer)
                // رأس المسحة المضيء
                if (rv < 1f) {
                    barP.shader = LinearGradient(
                        rx - 40f * d, 0f, rx + 6f * d, 0f,
                        Color.argb(0, 34, 211, 238), Color.argb(0xE0, 200, 250, 255), Shader.TileMode.CLAMP
                    )
                    c.drawRect(rx - 40f * d, oy, rx + 6f * d, oy + bmp.height, barP)
                }
            }
            // السطر الفرعي
            val ta = ease((t - 0.4f) / 0.12f) * (1f - ease((t - 0.58f) / 0.06f))
            if (ta > 0f) {
                tagP.alpha = (255 * ta).toInt()
                c.drawText("S K E T C H   S T U D I O", w / 2f, tagY + tagP.textSize, tagP)
            }
            // شقوق
            val cp = ease((t - 0.54f) / 0.1f)
            if (cp > 0f) {
                crackP.strokeWidth = 1.6f * d
                crackP.alpha = (235 * cp).toInt()
                for (cr in cracks) {
                    val len = cr[1] * cp
                    val mx = cx0 + cos(cr[0] + cr[2]) * len * 0.5f
                    val my = cy0 + sin(cr[0] + cr[2]) * len * 0.5f * 0.5f
                    val ex = cx0 + cos(cr[0]) * len
                    val ey = cy0 + sin(cr[0]) * len * 0.5f
                    c.drawLine(cx0, cy0, mx, my, crackP)
                    c.drawLine(mx, my, ex, ey, crackP)
                }
            }
        } else {
            val e = ((t - 0.64f) / 0.36f).coerceIn(0f, 1f)
            val a = (255 * (1f - ease((e - 0.3f) / 0.7f))).toInt().coerceIn(0, 255)
            paint.alpha = a
            edgeP.strokeWidth = 1.4f * d
            edgeP.alpha = (a * 0.8f).toInt()
            for (s in shards) {
                val px = s.vx * e
                val py = s.vy * e + 560f * e * e
                val sc = 1f - 0.4f * e * s.depth
                c.save()
                c.translate(ox + s.cx + px, oy + s.cy + py)
                c.rotate(s.rot * e)
                c.scale(sc, sc)
                c.translate(-s.cx, -s.cy)
                c.save()
                c.clipPath(s.path)
                c.drawBitmap(bmp, 0f, 0f, paint)
                c.restore()
                c.drawPath(s.path, edgeP)
                c.restore()
            }
        }
    }
}
